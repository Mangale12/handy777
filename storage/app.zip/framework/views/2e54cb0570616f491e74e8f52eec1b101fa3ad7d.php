<?php $__env->startSection('title'); ?>
     Redeems 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
  .dataTables_wrapper{
    padding: 25px;
  }
  .dataTables_wrapper .row{
    padding: 10px;
  }
  tbody tr td{
    border-bottom: none;
  }
  select,
  input[type="date"]{
      max-width:100%;
  }
</style>
       <?php if(Auth::user()->role == 'admin'): ?>

<?php endif; ?>
<div class="row" style="padding-top:20px;">
  <div class="col-12">
     <div class="card mb-4">
        <div class="card-body px-0 pt-0 pb-2">
           <div class="table-responsive p-0">
              <table class="table align-items-center mb-0 datatable">
                 <thead class="sticky" >
                    <tr  >
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-center">SN</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2 text-center">Full Name</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 text-center">Amount</th>
                    </tr>
                 </thead>
                 <tbody class="user-history-body">                          
                  <?php
                    $count = 1;
                  ?>
                  <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <tr>
                       <td class="align-middle text-center ">
                          <div class="d-flex px-2 py-1">
                             <div class="d-flex flex-column justify-content-center">
                                <h6 class=" mb-0 text-sm"><?php echo e($count++); ?></h6>
                             </div>
                          </div>
                       </td>
                       <td class="align-middle text-center ">
                          <div class="d-flex px-2 py-1">
                            <div class="d-flex flex-column justify-content-center">
                                <h6 class=" mb-0 text-sm"><?php echo e($item['form']['full_name']); ?></h6>
                            </div>
                          </div>
                       </td>
                       <td class="align-middle text-center ">
                          <span class="badge  bg-gradient-success"><?php echo e($item['sum']); ?></span>
                       </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tbody>
              </table>
           </div>
        </div>
     </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('newLayout.layouts.newLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/noorgame/public_html/resources/views/newLayout/redeems-history.blade.php ENDPATH**/ ?>